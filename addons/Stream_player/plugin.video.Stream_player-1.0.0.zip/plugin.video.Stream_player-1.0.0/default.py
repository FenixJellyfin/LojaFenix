# -*- coding: utf-8 -*-
import six
import sys
import os

# Compatibilidade de bibliotecas entre Python 2 e 3 (Kodi 18 e 19+)
if six.PY3:
    from urllib.parse import unquote_plus
else:
    from urllib import unquote_plus

from kodi_six import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin

# --- Configurações do Addon ---
plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')

# Tradução de caminhos para compatibilidade de SO (Android, Windows, Linux)
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
home = translate(addon.getAddonInfo('path'))

# Adiciona a pasta 'lib' ao PATH se ela existir no seu addon
modulo = os.path.join(home, "lib")
if os.path.exists(modulo):
    sys.path.append(modulo)

def log(msg):
    """ Envia mensagens para o log do Kodi para depuração """
    xbmc.log("[{}] {}".format(addonid, str(msg)), xbmc.LOGINFO)

def route(f):
    """ Decorador para gerenciar as rotas e capturar parâmetros da URL """
    def wrapper(*args, **kwargs):
        params_dict = {}
        param_string = sys.argv[2]
        
        if param_string:
            # Limpa o '?' e quebra os argumentos da URL
            split_commands = param_string.lstrip('?').split('&')
            for command in split_commands:
                if "=" in command:
                    key, value = command.split('=', 1)
                    params_dict[unquote_plus(key)] = unquote_plus(value)
                else:
                    params_dict[command] = ""
        
        action_f = f.__name__
        url = params_dict.get('url')

        # Se não houver URL, vai para o Main. Se houver, vai para o Player.
        if url is None and action_f == 'main':
            return f(params_dict)
        elif url and action_f == 'player':
            return f(params_dict)
            
    return wrapper

@route
def main(param):
    """ Função disparada quando o addon é aberto sem parâmetros """
    dialog = xbmcgui.Dialog()
    texto_ajuda = (
        "Plugin Resolver Ativo!\n\n"
        "Para usar, chame a URL via comando RunPlugin:\n"
        "plugin://{}/?url=LINK_DO_VIDEO\n\n"
        "Para legendas externas:\n"
        "&subs=URL_DA_LEGENDA.srt".format(addonid)
    )
    dialog.textviewer('Ajuda - ' + addonname, texto_ajuda)

@route
def player(param):
    """ Função que resolve o link e inicia o vídeo com legendas """
    url = param.get('url', '')
    subs_externa = param.get('subs', '') # Captura legenda se enviada por parâmetro
    
    if not url:
        return

    log("Iniciando processo de resolução para: " + url)
    
    try:
        import resolveurl
        
        # 1. Verifica se o link é suportado
        if resolveurl.HostedMediaFile(url).valid_url():
            # 2. Tenta extrair o link direto (MP4/MKV)
            resolved = resolveurl.resolve(url)
            
            if resolved:
                log("Sucesso! Link direto obtido.")
                
                # Criamos o item de reprodução
                liz = xbmcgui.ListItem(path=resolved)
                
                # --- TRATAMENTO DE LEGENDAS ---
                
                # Caso o vídeo tenha legendas EMBUTIDAS (MKV/MP4):
                # Definimos como 'true' para o Kodi habilitar o motor de busca interna
                liz.setProperty('IsPlayable', 'true')
                
                # Caso haja uma legenda EXTERNA enviada via parâmetro &subs=
                if subs_externa:
                    log("Adicionando legenda externa informada.")
                    liz.setSubtitles([subs_externa])
                
                # 3. Dá o comando de reprodução para o Kodi
                xbmcplugin.setResolvedUrl(handle, True, liz)
                
            else:
                # Falha ao resolver (link expirado ou erro no site)
                log("Erro: O ResolveURL não conseguiu extrair o link.")
                xbmcgui.Dialog().notification(addonname, 'Link offline ou erro no servidor.', icon, 5000)
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            # Site não consta na base do ResolveURL
            log("Erro: Site não suportado pelo ResolveURL.")
            xbmcgui.Dialog().notification(addonname, 'Este site não é suportado.', icon, 5000)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        # Erro de código ou falta de dependência
        log("Erro Crítico: " + str(e))
        xbmcgui.Dialog().notification(addonname, 'Erro interno no addon.', icon, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

if __name__ == '__main__':
    # O Kodi executa as funções baseadas no roteamento acima
    main()
    player()