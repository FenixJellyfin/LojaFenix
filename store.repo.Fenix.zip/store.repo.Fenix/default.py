import sys
import os
import re
import urllib.parse
import xml.etree.ElementTree as ET
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Obter o ID e handle do plugin
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# URL do seu store.txt no GitHub
STORE_URL = "https://raw.githubusercontent.com/FenixJellyfin/LojaFenix/main/store.txt"

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def get_store_data():
    """Lê o store.txt e extrai a categoria, nome, imagem e xml de cada item."""
    items = []
    try:
        response = requests.get(STORE_URL, timeout=10)
        if response.status_code == 200:
            lines = response.text.splitlines()
            pattern = re.compile(
                r'(?:category="([^"]+)"\s+)?addon_name="([^"]+)"\s+addon_image="([^"]+)"\s+addon_xml="([^"]+)"'
            )
            for line in lines:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                match = pattern.search(line)
                if match:
                    cat = match.group(1) if match.group(1) else "Geral"
                    name = match.group(2)
                    image = match.group(3)
                    xml_url = match.group(4)
                    items.append({
                        'category': cat,
                        'name': name,
                        'image': image,
                        'xml': xml_url
                    })
    except Exception as e:
        xbmc.log(f"LojaFenix Error reading store.txt: {e}", xbmc.LOGERROR)
    return items

def list_categories():
    """Lista as categorias encontradas no store.txt e define a imagem da pasta."""
    items = get_store_data()
    if not items:
        xbmcgui.Dialog().notification("Loja Fenix", "Nenhum addon encontrado no servidor", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    categories = {}
    for item in items:
        cat = item['category']
        if cat not in categories:
            categories[cat] = item['image']

    for cat, img_url in categories.items():
        url = build_url({'action': 'list_addons', 'category': cat})
        list_item = xbmcgui.ListItem(label=f"[B][COLOR gold]{cat}[/COLOR][/B]")
        list_item.setArt({'icon': img_url, 'thumb': img_url, 'poster': img_url, 'banner': img_url})
        list_item.setInfo('video', {'title': cat, 'plot': f'Ver addons na categoria {cat}'})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_addons(target_category):
    """Lista os addons que pertencem à categoria selecionada."""
    items = get_store_data()
    filtered_items = [i for i in items if i['category'] == target_category]

    for item in filtered_items:
        url = build_url({'action': 'install_addon', 'xml_url': item['xml']})
        list_item = xbmcgui.ListItem(label=item['name'])
        list_item.setArt({'icon': item['image'], 'thumb': item['image']})
        list_item.setInfo('video', {'title': item['name'], 'plot': f"Instalar {item['name']}"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def install_addon(xml_url):
    """Gera o link do ZIP a partir do addon.xml e instala o addon e as suas dependências."""
    dp = xbmcgui.DialogProgress()
    dp.create("Loja Fenix", "A ler dados do addon...")

    try:
        res = requests.get(xml_url, timeout=10)
        if res.status_code != 200:
            raise Exception("Não foi possível obter o addon.xml")

        root = ET.fromstring(res.text)
        addon_id = root.attrib.get('id')
        addon_version = root.attrib.get('version')

        if not addon_id or not addon_version:
            raise Exception("ID ou versão não encontrados no XML")

        requires = root.find('requires')
        if requires is not None:
            for dep in requires.findall('import'):
                dep_id = dep.attrib.get('addon')
                if dep_id and not dep_id.startswith('xbmc.'):
                    dp.update(30, f"A verificar dependência: {dep_id}")
                    xbmc.executebuiltin(f'InstallAddon({dep_id})')

        parsed = urllib.parse.urlparse(xml_url)
        dir_path = os.path.dirname(parsed.path)
        zip_url = f"{parsed.scheme}://{parsed.netloc}{dir_path}/{addon_id}-{addon_version}.zip"

        dp.update(60, f"A transferir {addon_id}...")

        packages_dir = xbmcvfs.translatePath('special://home/addons/packages/')
        if not os.path.exists(packages_dir):
            os.makedirs(packages_dir)

        zip_dest = os.path.join(packages_dir, f"{addon_id}-{addon_version}.zip")
        zip_res = requests.get(zip_url, stream=True, timeout=20)
        
        if zip_res.status_code != 200:
            raise Exception(f"Ficheiro ZIP não encontrado ({zip_res.status_code})")

        with open(zip_dest, 'wb') as f:
            for chunk in zip_res.iter_content(chunk_size=8192):
                if dp.iscanceled():
                    raise Exception("Instalação cancelada pelo utilizador")
                f.write(chunk)

        dp.update(90, "A extrair e a instalar...")

        import zipfile
        with zipfile.ZipFile(zip_dest, 'r') as zip_ref:
            addons_dir = xbmcvfs.translatePath('special://home/addons/')
            zip_ref.extractall(addons_dir)

        xbmc.executebuiltin('UpdateLocalAddons()')
        dp.update(100, "Instalação concluída!")
        dp.close()
        xbmcgui.Dialog().ok("Loja Fenix", f"{addon_id} instalado com sucesso!")

    except Exception as e:
        dp.close()
        xbmc.log(f"LojaFenix Install Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Loja Fenix", f"Falha na instalação: {e}", xbmcgui.NOTIFICATION_ERROR)

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    list_categories()
elif action == 'list_addons':
    category = params.get('category', 'Geral')
    list_addons(category)
elif action == 'install_addon':
    xml_url = params.get('xml_url')
    if xml_url:
        install_addon(xml_url)