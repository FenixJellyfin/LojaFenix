import sys
import os
import re
import zipfile
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# URLs e Configurações
STORE_URL = "https://raw.githubusercontent.com/FenixJellyfin/LojaFenix/main/store.txt"
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def build_url(query):
    """Constrói URLs internas do Kodi para navegação no addon."""
    return BASE_URL + '?' + urllib.parse.urlencode(query)


def show_help_dialog():
    """Abre uma janela de texto com as instruções de ativação de add-ons."""
    title = "Como ativar um Add-on"
    message = (
        "Se instalou um add-on da Loja Fenix e ele não aparecer ou não funcionar de imediato, basta fazer isto:\n\n"
        "1. No ecrã principal do Kodi, vá a Add-ons e clique no ícone da caixa aberta (no canto superior esquerdo) que diz 'Os meus add-ons'.\n\n"
        "2. Escolha a categoria do que instalou (por exemplo, Add-ons de vídeo ou Módulos).\n\n"
        "3. Clique em cima do nome do add-on que acabou de instalar.\n\n"
        "4. Se o botão 'Ativar' estiver visível na barra inferior, clique nele.\n\n"
        "Assim que estiver ativo, o add-on fica pronto a ser utilizado!"
    )
    xbmcgui.Dialog().textviewer(title, message)


def get_store_data():
    """Faz o download e interpreta o ficheiro store.txt lendo categorias, nomes, imagens e XMLs."""
    try:
        req = urllib.request.Request(STORE_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            content = response.read().decode('utf-8')
        
        items = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            cat_match = re.search(r'category=["\'](.*?)["\']', line)
            name_match = re.search(r'addon_name=["\'](.*?)["\']', line)
            img_match = re.search(r'addon_image=["\'](.*?)["\']', line)
            xml_match = re.search(r'addon_xml=["\'](.*?)["\']', line)
            
            if name_match and xml_match:
                category = cat_match.group(1) if cat_match else "Geral"
                name = name_match.group(1)
                img = img_match.group(1) if img_match else ""
                xml_url = xml_match.group(1)
                items.append({
                    'category': category,
                    'name': name,
                    'image': img,
                    'xml_url': xml_url
                })
        return items
    except Exception as e:
        xbmcgui.Dialog().ok("Erro Loja Fenix", f"Não foi possível carregar a loja:\n{str(e)}")
        return []


def list_categories():
    """Lista as categorias com ícones nativos de pasta do Kodi para maior rapidez."""
    
    # 1. Botão de Instruções/Ajuda no topo com ícone nativo
    help_url = build_url({'action': 'show_help'})
    help_item = xbmcgui.ListItem(label="[B][COLOR cyan][COMO ATIVAR ADD-ONS][/COLOR][/B]")
    help_item.setArt({'icon': 'DefaultIconInfo.png', 'thumb': 'DefaultIconInfo.png'})
    help_item.setInfo('video', {'title': 'Ajuda', 'plot': 'Clique para ver as instruções de ativação de add-ons.'})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=help_url, listitem=help_item, isFolder=False)

    # 2. Carrega as categorias do store.txt
    items = get_store_data()
    if not items:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Preserva a ordem original das categorias
    categories = []
    for item in items:
        cat = item['category']
        if cat not in categories:
            categories.append(cat)

    # 3. Cria as pastas com ícone nativo de pasta do Kodi (DefaultFolder.png)
    for cat in categories:
        url = build_url({'action': 'list_addons', 'category': cat})
        list_item = xbmcgui.ListItem(label=f"[B][COLOR gold]{cat}[/COLOR][/B]")
        list_item.setArt({
            'icon': 'DefaultFolder.png',
            'thumb': 'DefaultFolder.png',
            'poster': 'DefaultFolder.png',
            'banner': 'DefaultFolder.png'
        })
        list_item.setInfo('video', {'title': cat, 'plot': f'Ver addons na categoria {cat}'})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_addons(selected_category):
    """Lista os add-ons mostrando a imagem icon.png do addon ou o ícone padrão se estiver vazio."""
    items = get_store_data()
    for item in items:
        if item['category'] == selected_category:
            url = build_url({'action': 'install_addon', 'xml_url': item['xml_url']})
            list_item = xbmcgui.ListItem(label=item['name'])
            
            # Se houver imagem definida no store.txt usa essa imagem; caso contrário usa a caixa nativa
            addon_icon = item['image'] if item['image'] else 'DefaultAddon.png'
            list_item.setArt({'icon': addon_icon, 'thumb': addon_icon})
            
            list_item.setInfo('video', {'title': item['name'], 'plot': f'Clique para instalar/atualizar {item["name"]}'})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def install_addon(xml_url):
    """Lida com a transferência, extração e instalação do add-on."""
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Loja Fenix", "A ler ficheiro de configuração...")
    p_dialog.update(10)

    try:
        req = urllib.request.Request(xml_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            xml_data = response.read()

        root = ET.fromstring(xml_data)
        addon_id = root.attrib.get('id')
        addon_version = root.attrib.get('version')

        if not addon_id or not addon_version:
            p_dialog.close()
            xbmcgui.Dialog().ok("Erro", "O addon.xml fornecido é inválido.")
            return

        p_dialog.update(30, f"A preparar download de {addon_id} v{addon_version}...")

        base_zip_url = xml_url.rsplit('/', 1)[0]
        zip_url = f"{base_zip_url}/{addon_id}-{addon_version}.zip"

        temp_dir = xbmcvfs.translatePath('special://temp/')
        zip_path = os.path.join(temp_dir, f"{addon_id}.zip")
        addons_dir = xbmcvfs.translatePath('special://home/addons/')

        p_dialog.update(50, "A descarregar o ficheiro .zip...")
        zip_req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(zip_req) as response, open(zip_path, 'wb') as out_file:
            out_file.write(response.read())

        p_dialog.update(80, "A extrair os ficheiros...")

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addons_dir)

        if os.path.exists(zip_path):
            os.remove(zip_path)

        p_dialog.update(100, "Instalação concluída com sucesso!")
        p_dialog.close()

        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.executebuiltin("UpdateAddonRepos()")

        xbmcgui.Dialog().ok("Sucesso", f"{addon_id} foi instalado/atualizado com sucesso!\n\nSe o addon não aparecer de imediato, consulte o guia de ativação no topo do menu.")

    except Exception as e:
        p_dialog.close()
        xbmcgui.Dialog().ok("Erro na Instalação", f"Falha ao instalar o add-on:\n{str(e)}")


# Roteador principal do Add-on
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    list_categories()
elif action == 'show_help':
    show_help_dialog()
elif action == 'list_addons':
    category = params.get('category', 'Geral')
    list_addons(category)
elif action == 'install_addon':
    xml_url = params.get('xml_url')
    if xml_url:
        install_addon(xml_url)