# -*- coding: utf-8 -*-
import zipfile

def all(_in, _out, dp=None):
    if dp:
        allWithProgress(_in, _out, dp)
    else:
        allNoProgress(_in, _out)

def allNoProgress(_in, _out):
    try:
        with zipfile.ZipFile(_in, 'r') as zin:
            zin.extractall(_out)
    except Exception as e:
        pass

def allWithProgress(_in, _out, dp):
    try:
        with zipfile.ZipFile(_in, 'r') as zin:
            nFiles = float(len(zin.infolist()))
            count = 0
            for item in zin.infolist():
                count += 1
                update = int(count / nFiles * 100)
                dp.update(update)
                zin.extract(item, _out)
    except Exception as e:
        pass